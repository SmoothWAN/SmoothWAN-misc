/usr/bin/ping -c1 -I 4-USB 8.8.8.8 2>&1 | awk -F'/' 'END{ print (/^rtt/? $5:0) }' | cut -c 1-3
