echo -n "1:" 
ifstat -i 1-USB -b -n 1 1 | awk 'FNR==3{printf "%s", $2/(1000)}' | cut -c 1-3
