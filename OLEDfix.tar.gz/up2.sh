echo -n "2:" 
ifstat -i 2-USB -b -n 1 1 | awk 'FNR==3{printf "%s", $2/(1000)}' | cut -c 1-3
