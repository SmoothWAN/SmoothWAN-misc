echo -n "3:" 
ifstat -i 3-USB -b -n 1 1 | awk 'FNR==3{printf "%s", $3/(1000)}' | cut -c 1-3
